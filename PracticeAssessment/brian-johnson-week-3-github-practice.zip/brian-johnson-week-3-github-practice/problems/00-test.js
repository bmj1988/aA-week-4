/*

Write a function, `helloWorld`, that will return the string of 'Hello World!'

*/


function helloWorld() {
  return 'Hello World!'
}


/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
try {
  module.exports = helloWorld;
} catch (e) {
  module.exports = null;
}
